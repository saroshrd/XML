export default function radarBackwardCompat(option: any): void;
