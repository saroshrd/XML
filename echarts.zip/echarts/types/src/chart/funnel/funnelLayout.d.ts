import ExtensionAPI from '../../core/ExtensionAPI.js';
import GlobalModel from '../../model/Global.js';
export default function funnelLayout(ecModel: GlobalModel, api: ExtensionAPI): void;
