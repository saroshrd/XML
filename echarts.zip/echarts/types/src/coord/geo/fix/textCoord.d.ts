import { GeoJSONRegion } from '../Region.js';
export default function fixTextCoords(mapType: string, region: GeoJSONRegion): void;
