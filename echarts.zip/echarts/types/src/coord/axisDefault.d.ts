import { AxisBaseOption } from './axisCommonTypes.js';
declare const _default: {
    category: AxisBaseOption;
    value: AxisBaseOption;
    time: AxisBaseOption;
    log: AxisBaseOption;
};
export default _default;
