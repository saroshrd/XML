import { ECUnitOption } from '../../util/types.js';
export default function parallelPreprocessor(option: ECUnitOption): void;
