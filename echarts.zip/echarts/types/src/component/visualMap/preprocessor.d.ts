export default function visualMapPreprocessor(option: any): void;
