export declare function take(zr: any, resourceKey: any, userKey: any): void;
export declare function release(zr: any, resourceKey: any, userKey: any): void;
export declare function isTaken(zr: any, resourceKey: any): boolean;
